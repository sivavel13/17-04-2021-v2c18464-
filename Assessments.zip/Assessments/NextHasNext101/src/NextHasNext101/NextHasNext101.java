package NextHasNext101;

import java.util.*;

public class NextHasNext101 {
	public static void main (String[] args) {
		
		List<Integer> int_list = new ArrayList<Integer> ();
		
		int count=0; 


		int_list.add (10);
		int_list.add (20);
		int_list.add (30);
		int_list.add (40);
		int_list.add (50);


		System.out.println ("List elements are...");

		Iterator<Integer> it = int_list.iterator ();
		while (it.hasNext()){
			System.out.println (it.next());
			count+=1;
		}
		System.out.println ("Total traversed elements are: "+count);
	}
};