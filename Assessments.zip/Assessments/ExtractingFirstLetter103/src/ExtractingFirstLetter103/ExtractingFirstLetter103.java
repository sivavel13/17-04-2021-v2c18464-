package ExtractingFirstLetter103;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExtractingFirstLetter103
{
 static void printFirst(String s)
 {
     Pattern p = Pattern.compile("\\b[a-zA-Z]");
     Matcher m = p.matcher(s);

     while (m.find())
         System.out.print(m.group());

     System.out.println();
 }

 public static void main(String[] args)
 {
     String s1 = "Hai eagarly loade low one Way once regular lost diamond";
     String s2 = "Jack Antony Vasanth Akshai";
     printFirst(s1);
     printFirst(s2);
 }
}