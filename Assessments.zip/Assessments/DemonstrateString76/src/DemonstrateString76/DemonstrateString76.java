package DemonstrateString76;
class Best_Friend {
 String name;
 int age;
 String college;
 String course;
 String address;
 Best_Friend
 (String name, int age, String college, String course, String address)
 {
     this.name = name;
     this.age = age;
     this.college = college;
     this.course = course;
     this.address = address;
 }
}


 public class DemonstrateString76
 {
	 public static void main(String[] args)
	 {
	     Best_Friend b = 
	     new Best_Friend("Gulpreet Kaur", 21, "BIT MESRA", "M.TECH", "Kiriburu");
	     System.out.println(b);
	     System.out.println(b.toString());
	 } 
 }


////Java program to demonstrate toString() method class based
// 
//public class DemonstrateString76 {
//  public static void main(String[] args)
//      throws ClassNotFoundException
//  {
//      // returns the Class object for the class
//      // with the specified name
//      Class c2 = int.class;
//      Class c3 = void.class;
//
//      System.out.print("Class represented by c2: ");
//
//      // toString method on c2
//      System.out.println(c2.toString());
//
//      System.out.print("Class represented by c3: ");
//
//      // toString method on c3
//      System.out.println(c3.toString());
//  }
//}
