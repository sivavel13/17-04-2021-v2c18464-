package ComonElementRetainAll77;

import java.util.Arrays;
import java.util.HashSet;

public class ComonElementRetainAll77 {

	public static void main(String[] args) {

		 Integer[] i1 = {10, 23, 45,67,21};
		 
	        Integer[] i2 = {21, 32, 45, 76,21};
	 
	        HashSet<Integer> s = new HashSet<>(Arrays.asList(i1));;
	 
	        HashSet<Integer> s1 = new HashSet<>(Arrays.asList(i2));;
	 
	        s.retainAll(s1);
	 
	        System.out.println(s);    

	}
}