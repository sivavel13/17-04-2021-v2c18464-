package CheckThreadDaemon75;

public class CheckThreadDaemon75 extends Thread {
	

	
	public CheckThreadDaemon75(String name)
	{
        super(name);
    }
  
    public void run()
    {
        if(Thread.currentThread().isDaemon())
        { 
            System.out.println("Daemon thread"+" " +getName()); 
        } 
          
        else
        { 
            System.out.println("user thread"+" " +getName()); 
        } 
    }      
    public static void main(String[] args)
    { 
      
    	CheckThreadDaemon75 t4 = new CheckThreadDaemon75("t5");
    	CheckThreadDaemon75 t2 = new CheckThreadDaemon75("t2");
    	CheckThreadDaemon75 t3 = new CheckThreadDaemon75("t3");      
      
        t3.setDaemon(true);
        t4.start(); 
        t2.start();
        t3.start();        
    }
}