package FileRenameDemo109;

import java.io.File;

public class FileRenameDemo109 {
	public static void main(String[] args)
	{
		File oldName =
		new File("C:\\Users\\sivv2c18464\\sample1.txt");
		File newName =
		new File("C:\\Users\\sivv2c18464\\samples.txt");

		if (oldName.renameTo(newName))
			System.out.println("Renamed successfully");		
		else
			System.out.println("Error");		
	}
}
