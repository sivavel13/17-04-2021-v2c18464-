package tHreadDemo46;
public class tHreadDemo46 extends Thread  
{    
    public void run()  
    {    
        try  
        {   
            Thread.sleep(500);    
            System.out.println("javatpoint");    
        }
        catch(InterruptedException e)
        {    
            System.out.println("Exception handled "+e);    
        }   
        
        System.out.println("Thread is running...");    
    }    
    public static void main(String args[])  
    {    
    	tHreadDemo46 t1=new tHreadDemo46();    
    	tHreadDemo46 t2=new tHreadDemo46();  
        t1.start();     
        t1.interrupt();    
    }    
}   