package ExceptionThread73;

class main extends Thread{
	
	 public void run()
	    {
	        System.out.println("Thread");
	        throw new RuntimeException();
	    }
	}

public class ExceptionThread73 
{

	public static void main(String[] args) 
	{
			main t = new main();
		    t.start();
		    try 
		    {
		        Thread.sleep(2^0);
		    }
		    catch (Exception e) 
		    {		       
		        System.out.println("Exception" + e);
		    }
	}

}